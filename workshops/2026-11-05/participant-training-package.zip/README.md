# Orebit GeoSuite participant package —5November2026

Read dataset-provenance.md and data-dictionary.md. Synthetic educational data, CC BY4.0; never present these numbers as a real deposit estimate.

1. Download the versioned package from the link on the main deck. Unzip locally; verify CHECKSUMS.sha256. Use a current desktop browser. No Python is required for the application exercise.
2. Obtain the exact course application through the organizer's authorized distribution/login. A login wall, different build or unavailable module is a STOP; do not substitute another version without recording it. Portable exact-artifact local preview is an organizer-prepared alternative, not a publicly verified participant path yet.
3. Core Import: upload raw/collar.csv, survey.csv, assay.csv and litho.csv; declare EPSG32751 and meters/positive-down dip. Match counts in parameters-and-expected.json. Keep original inputs intact.
4. Follow participant-guide and slides in order: Validation→Desurvey→Merge→StripLog/Section→Assay EDA→Core saved surfaces/alternative loft→Assay reviewed population/EDA/composites→Resource model/support/search/estimation/CV/GT→export.
5. Compare exact parameters and method-specific expectations in parameters-and-expected.json. Surface and loft have different footprints; never compare their totals as algorithm bias. Boundary/informed support and missing grades remain explicit.
6. Final exercise: export auditCSV,PDF and project; compare supported volume, density, method, grade/tonnage and cutoff against expected-outputs. Do not tune data to force agreement. Record differences, source/build, method and steps.

Troubleshooting: wrong counts→check mapping/file classification; invalid structural data→source repair/reimport; reversed surfaces→swap assignment and rebuild/review; loft rejected→check every ring/terrain; NS loft insufficient bins→record refusal and use supported directions; stale confidence/report→rerun actual final downstream calculations; old cached app→save project,reopen online/reload and verify version through official receipt. Never bypass login, disable gates or erase projects to obtain PASS.

Evidence limitations and application-access readiness are maintained in final-go-no-go, not overridden by this dataset package.
