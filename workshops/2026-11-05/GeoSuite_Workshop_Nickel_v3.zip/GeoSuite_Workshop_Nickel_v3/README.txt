MULAI DI SINI — GEOSUITE NICKEL WORKSHOP v3
4–5 November 2026 | Ghozian Karami / Orebit.id | Data SINTETIS

ISI: README.txt (ini), dataset/ (input), output/ (pembanding dan penjelasan).

LATIHAN UTAMA — CORE → ASSAY → RESOURCE
1. Ekstrak ZIP. Buka versi GeoSuite yang dikonfirmasi instruktur.
2. Core > Import: pilih EMPAT CSV di dataset/:
   collar.csv, survey.csv, assay.csv, litho.csv. Jangan pilih folder output/.
3. Periksa340collar /680survey /8.751assay /1.344lithology.
   CRS EPSG:32751; meter; Z=elevasi/RL; FROM–TO=measured depth;
   DIP positif ke bawah. Empat file utama ini identik dengan baselinev2.1.
4. Ikuti PPT:QC > Desurvey > Merge > EDA > Domain(surface-pair ATAU loft)
   > review populasi Assay > komposit2m > variogram/grid/estimasi/CV > GT.
5. Kontak > Longest triangle edge mengatur dukunganTIN per surface.
   Kosong memakai2,5×median jarakXY. Angka200m adalah asumsi eksplisit
   latihan yang perlu review geologi; bukan syarat umum atau pengganti
   ground check. Simpan surface baru dan pilih di Build bila batas diubah.
6. BaselineSAP, density1,6t/m³, cutoff0%Ni:
   surface-pair21.298.329,56ton; loft684.068,61ton.
   Cocokkan metode/parameter yang sama. Pair/loft mempunyai footprint berbeda.

LATIHAN TAMBAHAN — GUNAKAN PROJECT BARU/SALINAN
A. SURVEY MELENGKUNG: import hanya4CSV di
   dataset/exercises/deviated-survey/ lalu Core > Desurvey > Merge.
   Ada3lubang/12station/52intervalassay. XYZ52midpoint berbeda dari12station.
   Angka solid/tonase latihan utama tidak berlaku untuk geometri latihan ini.
B. QA/QC: Assay > Upload dataset/exercises/qaqc-synthetic/qaqc-ni.csv.
   BukaQA/QC, pilihNi(%). Masukkan SIMNI mean1,00/SD0,04.
   Ini mock control, bukan CRM/certificate nyata. Amati kegagalan CRM,
   blank dan duplicate; lihat output/exercises/reference-results/.
   Jangan kirim data kontrol ini ke domain/compositing/Resource.
C. output/exercises/exercise_reference.py mereproduksi referensi Python.
   Jalankan dari environment Python yang sesuai; input tidak ditimpa.

PYTHON OPSIONAL — BACA PENJELASAN/GRAFIK TANPA KODE
https://github.com/ghoziankarami/orebit-datasets/blob/4cfec6585d95ddac0dcfd784ec6add6e10bed92f/workshops/2026-11-05/notebook/GeoSuite_Workshop_Nickel_Baca.md
Notebook pair/loft ada pada folder yang sama; selnya singkat dan implementasi
tersedia di companion engine. Paket baseline yang diambil notebook dipatok
hash; empatCSVutama identik dengan paket ini. KernelJupyter/Colab masih perlu
verifikasi terpisah; hasil Python berurutan tidak dianggap uji peserta.

PENTING
- Gunakan IMPORT untuk hasil workshop, bukan Sample bawaan(QCfixtureberbeda).
- Missing bukan nol. Ni/Co/Fe=%unsur;MgO/SiO2/Al2O3/Cr2O3=%oksida.
- SG tidak berdimensi; density1,6t/m³ adalah asumsi latihan yang eksplisit.
- Lihat output/chemistry-review-flags.csv:10flag basis kimia serta34missing
  perlu ditinjau; tidak dinormalisasi diam-diam. Bukan data lab tervalidasi.
- Solid dan clipped block support notebook berasal dari interpretasiUI yang
  sama; bukan interpretasi geologi independen atau complianceSNI/KCMI/JORC.
- CC BY4.0, kredit Ghozian Karami/Orebit.id; asal/unit/checksum di output/.
