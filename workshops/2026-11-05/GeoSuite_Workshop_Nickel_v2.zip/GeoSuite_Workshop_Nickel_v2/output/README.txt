OUTPUT REFERENSI — BUKAN INPUT AWAL CORE
pair/: solid SAP dari dua surface; loft/: solid SAP dari tiga section.
Kedua footprint berbeda sehingga totalnya tidak boleh dianggap pembanding
akurasi metode estimasi. composites-2m.csv dan block-model-reference.csv adalah
hasil contoh GeoSuite. interpreted-solid.json adalah interpretasi geologi beku,
bukan pengukuran mentah; notebook memakainya untuk menjelaskan clipping/support.
parameters.json menyimpan konfigurasi dan angka acuan dengan source historisnya.
Notebook menghitung ulang bagian numerik yang disebutkan, dan membedakan hasil
hitungnya dari geometri/dukungan blok yang diberikan. Input geologi bukan validasi
geologi independen. File CSV referensi memakai -999 untuk blok tidak diestimasi;
jangan memperlakukannya sebagai kadar Ni negatif nyata.
