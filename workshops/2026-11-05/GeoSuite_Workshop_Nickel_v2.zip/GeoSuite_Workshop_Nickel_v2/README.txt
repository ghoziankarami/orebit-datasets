MULAI DI SINI — WORKSHOP GEOSUITE NICKEL — v2.1
4–5 November 2026 | Ghozian Karami / Orebit.id

Jalur utama: ikuti demonstrasi GeoSuite dan import sendiri empat CSV.
Notebook Python adalah pendamping untuk membaca/mengulang perhitungan.

ISI PAKET
README.txt  Petunjuk singkat ini.
dataset/    Empat file input awal Core.
output/     Hasil contoh, parameter, dan interpretasi untuk pembanding.
            Jangan import folder output/ bersama empat CSV input.

MULAI DI GEOSUITE
1. Ekstrak ZIP dan buka versi aplikasi yang dikonfirmasi instruktur.
2. Core > Import: pilih collar.csv, survey.csv, assay.csv dan litho.csv
   dari folder dataset/ sekaligus. Tidak perlu Python untuk langkah ini.
3. Periksa mapping dan metadata: WGS84 / UTM 51S (EPSG:32751), meter,
   DIP positif ke bawah. Semua lubang contoh ini vertikal (DIP=90°).
   ZCOLLAR adalah elevasi/RL; FROM dan TO adalah kedalaman interval.
4. Cocokkan jumlah: 340 collar, 680 survey, 8.751 assay, 1.344 lithology.
   BHID menghubungkan tabel; kadar *_PCT dalam persen. Missing bukan nol.
5. Ikuti PPT/panduan: QC dan visualisasi Core > EDA Assay > Domain Core
   (surface-pair ATAU loft) > review/composite Assay > variogram, model,
   estimasi dan Cross-Val Resource > grade–tonnage > laporan/export.
6. Simpan pekerjaan sendiri, misalnya di hasil-saya/. Bandingkan dengan
   output/pair/ atau output/loft/ yang SESUAI metode dan parameternya.

NOTEBOOK PYTHON — OPSIONAL
Baca notebook beserta hasilnya di GitHub:
https://github.com/ghoziankarami/orebit-datasets/blob/training/workshop-20261105-v1/workshops/2026-11-05/notebook/GeoSuite_Workshop_Nickel.ipynb
GitHub menampilkan notebook. Untuk menjalankan, unduh file .ipynb lalu buka
melalui Jupyter atau Colab (File > Upload notebook), dan pilih Run All.
Pilih MODE='pair' atau MODE='loft'; jalankan ulang semua sel setelah mengganti.
Empat CSV sama dengan GeoSuite. Solid dan block support yang dipakai sebagai
input geologi referensi dinyatakan jelas; notebook bukan pengganti digitize
atau review geolog. Baca status pengujian/kernel pada halaman notebook.

APAKAH SAMA DENGAN TOMBOL SAMPLE BAWAAN?
Tidak identik. Sample Core adalah latihan QC dengan masalah linkage yang
memang didokumentasikan. Paket workshop memilih 340 lubang utuh dengan batas
SAP lengkap, tanpa memilih kadar atau mengubah pengukurannya. Untuk mengikuti
hasil demonstrasi dan notebook, gunakan IMPORT empat CSV ini, bukan Sample.

HASIL PEMBANDING
Dengan parameter baseline yang sama (SAP, density 1,6 t/m³, cutoff 0% Ni):
- Surface-pair: 21.298.329,56 ton.
- Loft:            684.068,61 ton.
UI dan notebook harus cocok untuk metode yang SAMA. Pair dan loft pada latihan
ini berbeda footprint, sehingga total keduanya memang berbeda.

DATA DAN BATAS PENGGUNAAN
Data SINTETIS, bukan endapan nyata. CC BY 4.0; kredit Ghozian Karami/Orebit.id.
Lisensi: https://creativecommons.org/licenses/by/4.0/
Asal data, kamus/unit, dukungan boundary, parameter dan batas validasi ada pada
output/. Ini latihan, bukan laporan Mineral Resource patuh SNI/KCMI/JORC atau
sign-off Competent Person. Jika hasil berbeda, catat versi, metode, parameter,
pesan dan langkah; jangan mengubah raw data hanya untuk menyamakan angka.
