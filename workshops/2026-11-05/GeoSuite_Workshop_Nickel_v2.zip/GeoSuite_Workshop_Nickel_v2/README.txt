MULAI DI SINI — WORKSHOP GEOSUITE NICKEL • v2 • 4–5 NOVEMBER 2026

PILIH JALUR BELAJAR
A. GeoSuite (jalur utama demonstrasi): import sendiri empat CSV pada dataset/.
B. Python notebook (pendamping): buka tautan notebook di bawah. Di GitHub Anda
   bisa MEMBACA kode dan hasil; untuk MENJALANKAN, pakai Jupyter lokal atau Colab.
Keduanya memakai empat file pengukuran yang sama. Tidak perlu Python untuk A.

ISI PAKET
README.txt  Petunjuk ini.
dataset/    Empat input: collar.csv, survey.csv, assay.csv, litho.csv.
output/     Hasil referensi, parameter dan solid interpretasi. Bukan input awal
            Core. Jangan import folder output/ bersama empat CSV pengukuran.

LANGKAH AWAL GEOSUITE
1. Ekstrak ZIP. Buka aplikasi/versi yang dikonfirmasi instruktur melalui akses
   resmi. Jangan diam-diam mengganti versi jika akses tidak tersedia.
2. Core > Import: pilih empat CSV pada dataset/ SEKALIGUS.
3. Periksa mapping, WGS84 / UTM 51S (EPSG:32751), koordinat/depth/elevasi meter,
   DIP positif ke bawah. Data ini seluruhnya lubang vertikal, DIP=90 derajat.
   XCOLLAR=Easting, YCOLLAR=Northing, ZCOLLAR=elevasi/RL; bukan kedalaman.
4. Cocokkan jumlah: 340 collar; 680 survey; 8.751 assay; 1.344 lithology.
   BHID menghubungkan tabel. FROM/TO adalah kedalaman interval dalam meter.
   NI_PCT/CO_PCT/FE_PCT dan kolom *_PCT = persen, bukan fraksi0–1; SG=t/m³.
   Missing tetap missing. Jangan mengganti nilai kosong dengan nol.
5. Lanjutkan sesuai PPT/panduan: Validation > Desurvey/Merge > log/section >
   Assay EDA > Core Domain (surface-pair ATAU loft) > Assay review/composite >
   Resource variogram/model/estimasi > evaluasi/grade-tonnage > export.
6. Simpan hasil Anda di folder SENDIRI, misalnya hasil-saya/. Bandingkan dengan
   output/pair/ atau output/loft/ yang sesuai, jangan mencampurkan footprint.

NOTEBOOK PYTHON
https://github.com/ghoziankarami/orebit-datasets/blob/training/workshop-20261105-v1/workshops/2026-11-05/notebook/GeoSuite_Workshop_Nickel.ipynb
Notebook membaca file pengukuran yang sama dan menjelaskan tiap tahap dalam
bahasa Indonesia. Solid interpretasi dan dukungan blok dari GeoSuite dipakai
sebagai input geologi referensi yang dinyatakan jelas, bukan dibuat otomatis
oleh statistik. Ini bukan pengganti digitize UI atau review seorang geolog.
Status eksekusi notebook dan cara install ada di halaman notebook; GitHub
menampilkan notebook, tetapi bukan kernel Python interaktif.

APAKAH SAMA DENGAN TOMBOL SAMPLE DI GEOSUITE?
Tidak identik. Sample bawaan Core adalah kasus latihan QC dengan tiga masalah
linkage yang didokumentasikan (349 collar/700 survey/8.896 assay/1.368 geology).
Sumber sample yang dikoreksi mempunyai350 collar dan1.372 geology.
Paket workshop ini mempertahankan340 lubang utuh dari sumber sintetis yang sama:
10 lubang tanpa batas bawah SAP yang lengkap dikeluarkan TANPA memilih kadar
atau mengubah pengukuran. Untuk workshop gunakan IMPORT CSV ini, bukan Sample.

GEOLOGI DAN HASIL REFERENSI
LIM dan SAP adalah kode litologi. Domain=interpretasi volume, surface=batas.
Top/Bottom tidak boleh menggabungkan SAP yang terpisah melintasi material/gap.
Pada contoh surface-pair,38 lubang di batas lateral mempunyai468m dukungan
unassigned;302 lubang interior memberi4.122m. Raw340 lubang tetap disimpan.
Density1,6t/m³ adalah asumsi latihan, bukan hasil pengukuran tervalidasi.
Volume mesh berbeda dari volume blok terisi. Hasil ini bukan Mineral Resource
terklasifikasi/patuh SNI/KCMI/JORC dan bukan sign-off Competent Person.

SUMBER & IZIN
Data sintetis, BUKAN endapan nyata. CC BY4.0, kredit Ghozian Karami / Orebit.id.
Sumber: ghoziankarami/orebit-datasets@6b93ac48df79264fda20e4ffc10716280bd2ee8a,
folder02-nikel-laterit. Pengukuran empat CSV identik byte-for-byte dengan paket
workshop v1@46c2958657d7bd437ed90df7f48114e91bb3a5ed; v2 merapikan kemasan.
Lisensi: https://creativecommons.org/licenses/by/4.0/
GeoSuite adalah perangkat lunak GPL-3.0-only; paket dataset bukan rilis aplikasi.

JIKA HASIL BERBEDA
Catat versi app, modepair/loft, parameter, pesan, langkah dan screenshot/proyek.
Ground Fail bukan diperbaiki dengan mengganti batas triangle edge loft atau
menurunkan ring sembarang. Jangan mengubah data supaya sesuai angka referensi.
